# HVAC Scheduler — Clean Starter (Netlify Blobs)
Clean reset of your Master Template with dead-simple save/load via Netlify Blobs.
## Quick Start
1) New GitHub repo → push these files.
2) Netlify → New Site from Git → deploy.
3) In your HTML, include:
   <script src="assets/save-load.js" defer></script>
That's it. Edits auto-save; refresh auto-loads.
